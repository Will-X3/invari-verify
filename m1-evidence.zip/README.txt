INVARI kOS -- CHECKING A REFUSED PROPOSAL YOURSELF
==================================================

What happened
-------------
A second "Firearm_Manufactured" was proposed for a firearm that already had
one (asset 6acbe57e799dbf0fcf8def65, chain head v1). The kernel refused it:
MANUFACTURE_NOT_GENESIS. All data is synthetic (pre-pilot test data).

What you need
-------------
Node.js (any current LTS). No npm install, no network, no Invari server.

  kernel/canonicalize.js         canonical serializer (what gets hashed)
  kernel/seal.js                 SHA-256 + Ed25519 verification
  kernel/tools/verifyExport.js   verifies a chain export
  kernel/tools/verifyRejection.js  verifies the refusal against the chain
  asset-export.json              Invari's export of the asset's chain
  receipt-rcpt_88524a38e31849d08063a6083705e8aa.json   the refusal receipt
  public-keys.json               Invari's public signing key

Do not trust public-keys.json from this folder alone: compare it with the
key published in the post. A forged folder could carry its own key.

Run
---
  node kernel/tools/verifyRejection.js asset-export.json receipt-rcpt_88524a38e31849d08063a6083705e8aa.json public-keys.json --expect-head 67d764054abf00d4533b755c66c4f1bea5f2a4020c409fbe37e8e118ffdc78dc

Exit code 0 and "RESULT: PASS" means every check below held.

What it checks
--------------
1. The chain. Every entry's hash recomputes from its own content
   (SHA-256 over "invari.kos.ledger.entry.v4\n" + canonical JSON), every
   Ed25519 signature verifies under the published key, versions start at v1
   and every previousEntryHash links.
2. The receipt. Its inputCommitHash recomputes from {tenantId, proposal}
   (SHA-256 over "invari.kos.receipt.input.v4\n" + canonical JSON) and its
   signature verifies: Invari's kernel issued a receipt for exactly this
   proposal.
3. The proposal was for this asset, formed against v1, by the tenant that
   held v1.
4. No entry on the chain was written from this receipt.
5. The signed proposal names the head it was formed against (stateHash),
   and that is v1's entryHash -- so the receipt, signed at 19:39:46 UTC on
   2026-10-11, is itself a record of the head at the moment of refusal.
   v1 is still the chain's last entry, and equals the published head hash
   (--expect-head).

The export also contains one entry from Invari's platform ledger: the
record of this export itself (Chain_Export_Completed). It is reported as a
"partial chain" because its earlier entries are not part of this export.

What it does NOT prove -- stated plainly
----------------------------------------
- The outcome ("REJECTED" and the reason) is written when the receipt is
  finalized and is NOT covered by the signature yet. The tool prints it,
  marked NOT SIGNED. What makes the refusal credible is checks 2-5: a signed
  proposal against v1, and no entry written from it. Signing the outcome is
  on the roadmap.
- Whoever holds Invari's private key could re-sign a rewritten chain, and
  the receipt's stateHash is signed with the same key. The defence is a head
  hash published somewhere Invari can't rewrite, before the export. For this
  example the head hash is published after the fact (with this post); from
  now on head hashes are published at the time of each refusal.
